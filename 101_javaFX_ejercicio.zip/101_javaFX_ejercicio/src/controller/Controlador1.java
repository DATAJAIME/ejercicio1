package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controlador1 {

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnLogin;

    @FXML
    void login(ActionEvent event) {
    	//Creamos la alerta que aparecer� para decirnos si hemos introducido bien las credenciales
    	Alert alert = new Alert(AlertType.INFORMATION);
    	alert.setTitle("Menuda maquina de matar");
    	alert.setHeaderText(null);
    	
    	//Variables ficticias para emular un inicio de sesi�n
    	String email = "prueba@gmail.com";
    	String password = "123456";
    	
    	//Comprobamos si coinciden los datos del login
    	if(txtEmail.getText().equals(email) && txtPassword.getText().equals(password)) {
    		//Si coincide, nos muestra el siguiente mensaje
    		try {
    	           FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/views/scene2.fxml"));
    	           Parent root1 = (Parent) fxmlLoader.load();
    	           Stage stage = new Stage();
    	           stage.setScene(new Scene(root1));  
    	           stage.show();
    	       } catch(Exception e) {
    	           e.printStackTrace();
    	       }
    	}else {
    		//Si no hemos escrito bien nuestra credenciales, nos muestra este otro
    		alert.setContentText("Email y/o contrase�a incorrectos");
    		System.out.println(email +" "+password+" "+txtEmail.getText()+" "+txtPassword.getText()+" ");
    	}
    	
    	alert.showAndWait();
    }

}
